/*
 * Copyright 2012-2020 Aerospike, Inc.
 *
 * Portions may be licensed to Aerospike, Inc. under one or more contributor
 * license agreements WHICH ARE COMPATIBLE WITH THE APACHE LICENSE, VERSION 2.0.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package com.aerospike.storage.adaptive;

import com.aerospike.client.*;
import com.aerospike.client.cdt.*;
import com.aerospike.client.command.Buffer;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.nio.ByteBuffer;
import java.time.*;
import java.util.*;

import static org.junit.Assert.*;


public class TestAdaptiveMapTranHistory {

    private final String HOST = "172.28.128.5";
    private final String NAMESPACE = "test";
    private final String SET = "testAdapt";
    private final String MAP_BIN = "mapBin";
    private final int MAP_SPLIT_SIZE = 100;
    private AdaptiveMap library;
    private AerospikeClient client;
    private IAdaptiveMap adaptiveMapWithValueKey;
    private IAdaptiveMap adaptiveMapWithDigestKey;

    @Before
    public void setUp() throws Exception {
        client = new AerospikeClient(HOST, 3000);
        MapPolicy policy = new MapPolicy(MapOrder.KEY_ORDERED, MapWriteFlags.DEFAULT);

        // Use the underlying functions for restricted functions
        library = new AdaptiveMap(client, NAMESPACE, SET, MAP_BIN, policy, false, MAP_SPLIT_SIZE);

        // Set up the interface to use for primary operations
        adaptiveMapWithValueKey = library;

        adaptiveMapWithDigestKey = new AdaptiveMap(client, NAMESPACE, SET, MAP_BIN, policy, true, MAP_SPLIT_SIZE);
    }

    @After
    public void tearDown() throws Exception {
        client.close();
    }

    @Test
    public void testMultiRecordGetTranHistoryList() {
        System.out.printf("\n*** testMultiRecordGet ***\n");
        // Clean up after previous runs
        //client.truncate(null, NAMESPACE, SET, null);
        final int DAYS = 30;
        final int COUNT_PER_DAY = 10 * MAP_SPLIT_SIZE;
        String basePart = "12345";
        LocalDateTime start = LocalDateTime.of(LocalDate.of(2020, 03, 01), LocalTime.of(0, 0, 0));
        LocalDateTime end = LocalDateTime.of(LocalDate.of(2020, 03, 02), LocalTime.of(0, 0, 0));
        String trnHistoryJson = "{ \"tranId\": \"transactionId\", \"tranDate\": \"1583001761000\", \"trnType\": \"C\", \"tranAmount\": 2002.4, \"partTrnSerialNo\": \"01\" }";
        for (LocalDateTime date = start; date.isBefore(end); date = date.plusDays(1)) {
            String baseKey = basePart + ":" + date.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
            for (int i = 0; i < COUNT_PER_DAY + 5 * date.getDayOfMonth(); i++) {
                Instant instant = date.atZone(ZoneId.systemDefault()).plusSeconds(i).toInstant();
                try {
                    List<String> response = (List<String>) this.adaptiveMapWithValueKey.get(baseKey, instant.toEpochMilli());
                    response.add(trnHistoryJson.replace("transactionId", UUID.randomUUID().toString()));
                    this.adaptiveMapWithValueKey.put(baseKey, instant.toEpochMilli(), null, Value.get(response));
                } catch(Exception e) {
                    List<String> transactions = Arrays.asList(trnHistoryJson.replace("transactionId", UUID.randomUUID().toString()));
                    this.adaptiveMapWithValueKey.put(baseKey, instant.toEpochMilli(), null, Value.get(transactions));
                }
            }
            System.out.println(baseKey);
        }
    }

    @Test
    public void testGetDayRecordList() {
        try {
            List<String> response = (List<String>) this.adaptiveMapWithValueKey.get("12345:1583001000000", 1583001000000l);
            System.out.println(response.size());
        } catch(Exception e) {
            e.printStackTrace();
        }

//        if (response != null && !response.isEmpty())
//            System.out.println(response.get("transaction"));
//        TreeMap<Object, Object>[] treeMap = this.adaptiveMapWithValueKey.getAll(null, new String[]{"12345:1583001000000"});
//        System.out.println(treeMap[0].toString());
    }

    @Test
    public void testMultiRecordGetTranHistory() {
        System.out.printf("\n*** testMultiRecordGet ***\n");
        // Clean up after previous runs
        client.truncate(null, NAMESPACE, SET, null);
        final int DAYS = 30;
        final int COUNT_PER_DAY = 10 * MAP_SPLIT_SIZE;
        String basePart = "12345";
        LocalDateTime start = LocalDateTime.of(LocalDate.of(2020, 03, 01), LocalTime.of(0, 0, 0));
        LocalDateTime end = LocalDateTime.of(LocalDate.of(2020, 03, 10), LocalTime.of(0, 0, 0));
        //LocalDate end = LocalDate.of(2020, 03, 10);
        List<String> inserted = new ArrayList<>();
        String trnHistoryJson = "{ \"tranId\": \"transactionId\", \"tranDate\": \"1583001761000\", \"trnType\": \"C\", \"tranAmount\": 2002.4, \"partTrnSerialNo\": \"01\" }";
        for (LocalDateTime date = start; date.isBefore(end); date = date.plusDays(1)) {
            String baseKey = basePart + ":" + date.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
            for (int i = 0; i < COUNT_PER_DAY + 5 * date.getDayOfMonth(); i++) {
                Instant instant = date.atZone(ZoneId.systemDefault()).plusSeconds(i).toInstant();
                Map<String, Object> map = new HashMap<>();
                map.put("transaction", Arrays.asList(trnHistoryJson));
                Map<String, Object> response = (Map<String, Object>) this.adaptiveMapWithValueKey.get(baseKey, instant.toEpochMilli());
                if (response != null && !response.isEmpty()) {
                    ((List<String>) response.get("transaction")).add(trnHistoryJson);
                } else {
                    map.put("transaction", Arrays.asList(trnHistoryJson));
                }
                this.adaptiveMapWithValueKey.put(baseKey, instant.toEpochMilli(), null, Value.get(map));
            }
            System.out.println(baseKey);
        }
    }

    @Test
    public void testGetDayRecord() {
        Map<String, Integer> map = new HashMap<>();
        map.put("day", 2);
        map.put("i", 552);
        map.put("count", 1557);
        map.put("customkey", 777);
        //this.adaptiveMapWithValueKey.put("base" + ":" + 2, 2 + "-" + 552, null, Value.get(map));
        Map<String, Object> response = (Map<String, Object>) this.adaptiveMapWithValueKey.get("12345:1583001000000", 1583001000000l);
        if (response != null && !response.isEmpty())
            System.out.println(response.get("transaction"));
        TreeMap<Object, Object>[] treeMap = this.adaptiveMapWithValueKey.getAll(null, new String[]{"12345:1583001000000"});
        System.out.println(treeMap[0].toString());
    }

    @Test
    public void testMultiRecordGet() {
        System.out.printf("\n*** testMultiRecordGet ***\n");
        // Clean up after previous runs
        client.truncate(null, NAMESPACE, SET, null);
        final int DAYS = 30;
        final int COUNT_PER_DAY = 10 * MAP_SPLIT_SIZE;
        String basePart = "base";
        int count = 0;
        for (int day = 1; day <= DAYS; day++) {
            for (int i = 0; i < COUNT_PER_DAY + 5 * day; i++) {
                Map<String, Integer> map = new HashMap<>();
                map.put("day", day);
                map.put("i", i);
                map.put("count", count++);
                this.adaptiveMapWithValueKey.put(basePart + ":" + day, day + "-" + i, null, Value.get(map));

            }
        }
        String[] keys = new String[DAYS];
        for (int i = 1; i <= DAYS; i++) {
            keys[i - 1] = basePart + ":" + i;
        }

        long now = System.nanoTime();
        TreeMap<Object, Object>[] records = this.adaptiveMapWithValueKey.getAll(null, keys);
        long time = System.nanoTime() - now;

        int totalCount = 0;
        Set<Long> counts = new HashSet<>();
        for (int day = 1; day <= DAYS; day++) {
            TreeMap<Object, Object> dayRecords = records[day - 1];
            Set<Long> dayCounts = new HashSet<>();
            for (Object valueObj : dayRecords.values()) {
                Map<String, Long> value = (Map<String, Long>) valueObj;
                dayCounts.add(value.get("i"));
                counts.add(value.get("count"));
                totalCount++;
            }
            // Now validate that we have all the day counters
            for (long j = 0; j < COUNT_PER_DAY + 5 * day; j++) {
                assertTrue("Map for day " + day + " does not contain day-count of " + j, dayCounts.contains(j));
                dayCounts.remove(j);
            }
            assertTrue("Day counts for day " + day + " should be empty, but still contains " + dayCounts, dayCounts.isEmpty());
        }
        long aCount = 0;
        for (int day = 1; day <= DAYS; day++) {
            for (int i = 0; i < COUNT_PER_DAY + 5 * day; i++) {
                assertTrue("Missing count of " + aCount, counts.contains(aCount));
                counts.remove(aCount);
                aCount++;
            }
        }
        assertTrue("Counts should be empty, but still contains " + counts, counts.isEmpty());
        System.out.printf("Retreived %d days records with %d total entries in %.1fms\n", DAYS, totalCount, time / 1000000.0);
    }
}
